package com.example.javafx.triangulation;

public interface TriangleTreeComparator {
    boolean isRightTriangle(TriangleTreeNode node);
}
